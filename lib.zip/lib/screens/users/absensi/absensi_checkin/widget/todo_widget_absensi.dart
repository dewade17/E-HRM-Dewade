import 'package:flutter/material.dart';

class TodoWidgetAbsensi extends StatefulWidget {
  const TodoWidgetAbsensi({super.key});

  @override
  State<TodoWidgetAbsensi> createState() => _TodoWidgetAbsensiState();
}

class _TodoWidgetAbsensiState extends State<TodoWidgetAbsensi> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
